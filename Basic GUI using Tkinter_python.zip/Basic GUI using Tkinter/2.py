#Learning:- text entry box, submit button 
from tkinter import *

#----------------------------
def click_function():
    txt = textentry.get() # collect text in text box
    print(txt)
#----------------------------


#------------------main----------------------
window = Tk()  # creates a window
window.title("Student Result")  # window Title

# create a text entry box
textentry = Entry(window,width=20,bg="white")
textentry.grid(row=2,column=0,sticky=S)

# add a submit button , click is a function defined at top
b= Button(window,text="SUBMIT",width=6,command=click_function)
b.grid(row=3,column=0,sticky=S)

window.mainloop()
