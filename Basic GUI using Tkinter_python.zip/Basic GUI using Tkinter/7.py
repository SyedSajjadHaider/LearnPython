# all + output text 
from tkinter import *

#---click function defination-------
def click():
    txt = text_entry.get() # collect text in text box
    output.delete(0.0,END)
    try:
        result = student_result[txt]
    except:
        result ="refer notice board"
        
    output.insert(END,result)
#----------------------------------


# main ----------------------------
window = Tk()  # important line , it create a window
window.title("Student Result") # window title


#--------------LABLE 1 ----------
lb = Label(window,text="Student Result Program",bg="yellow",fg="black",font="none 12 bold")
lb.grid(row=1,column=0,sticky=W)


#-------------LABLE 2 -----------
lb = Label(window,text="Enter Roll Number",fg="black",font="none 10 bold")
lb.grid(row=2,column=0,sticky=S)


# create a text entry box
text_entry = Entry(window,width=20,bg="white")
text_entry.grid(row=3,column=0,sticky=S)

# add a submit button
# click is a  user defined function 
b= Button(window,text="SUBMIT",width=6,command=click)
b.grid(row=4,column=0,sticky=S)


#-------------LABLE 3 RESULT -----------
lb = Label(window,text="RESULT",fg="black",font="none 10 bold")
lb.grid(row=5,column=0,sticky=S)

# Create a text box
output = Text(window,width=30,height=4,wrap=WORD,background="white")
output.grid(row=5,column=0,columnspan=3,sticky=W)

student_result={'102':'---PASS---',
            '103':'---FAIL---',
            '104':'---PASS---',
            '105':'---FAIL---',
            '106':'---PASS---',
            '107':'---FAIL---',
            '108':'---PASS---',
            '109':'---PASS---',
            '111':'---PASS---',
            }



window.mainloop()
