# create a basic window with a lable string
from tkinter import *

#------------------main----------------------
window = Tk()  # creates a window
window.title("HELLO WORLD TITLE")  # window Title

# lable (string in window with grid info)
lb = Label(window,text="--HELLO WORLD PROGRAM",bg="yellow",fg="black",font="none 12 bold")
lb.grid(row=1,column=0,sticky=S)

window.mainloop()
