# lable , text entry, submit button
from tkinter import *

#---click function defination-------
def click():
    txt = text_entry.get() # collect text from variable text_entry to txt 
    print(txt)
#----------------------------------

#----------------main---------------
window = Tk()  # important line , it create a window
window.title("Student Result") # window title

#--------------LABLE 1 ----------
lb = Label(window,text="Student Result Program",bg="yellow",fg="black",font="none 12 bold")
lb.grid(row=1,column=0,sticky=W)

#-------------LABLE 2 -----------
lb = Label(window,text="Enter Roll Number",fg="black",font="none 10 bold")
lb.grid(row=2,column=0,sticky=S)

#------create a text entry box-----
text_entry = Entry(window,width=20,bg="white")
text_entry.grid(row=3,column=0,sticky=S)

# add a submit button
# click is a  user defined function 
b= Button(window,text="SUBMIT",width=6,command=click)
b.grid(row=4,column=0,sticky=S)

window.mainloop()
